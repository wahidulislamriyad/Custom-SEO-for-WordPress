<?php
if( isset( $_POST['author_name'] ) && $_POST['author_name'] != '' ) {
    file_put_contents(__DIR__."/cpages/name.txt", $_POST['author_name']);
    echo 'Author Name Updated<br>';
} else {
     file_put_contents(__DIR__."/cpages/name.txt", "");
     echo 'Author Name cleared<br>';
}

if( isset( $_POST['description'] ) && $_POST['description'] != '' ) {
    file_put_contents(__DIR__."/cpages/description.txt", $_POST['description']);
    echo 'Description updated<br>';
} else {
    file_put_contents(__DIR__."/cpages/description.txt", "");
    echo 'Desription cleared<br>';
}

if( isset( $_POST['ctags'] ) && $_POST['ctags'] != '' ) {
    file_put_contents(__DIR__."/cpages/tags.txt", $_POST['ctags']);
    echo 'Tags updated<br>';
} else {
    file_put_contents(__DIR__."/cpages/tags.txt", "");
    echo 'Tags cleared<br>';
}
echo '<script>setTimeout(window.top.location.reload(), 1000);</script>'
?>