<?php
/*
Plugin Name:  Custom SEO
Plugin URI:   https://r-server.000webhostapp.com
Description:  A custom SEO plugin for Wordpress site
Version:      1.0
Author:       Wahidul Islam Riyad
Author URI:   https://web.facebook.com/wahidulislamriyad
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
*/
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
//echo "Hello World!";

/**
* Print SEO tags in the header
* @return void
*/

/*if ( isset( $plugin_data['slug'] ) && current_user_can( 'install_plugins' ) ) {
    $plugin_meta[] = sprintf( '<a href="%s" class="thickbox" aria-label="%s" data-title="%s">%s</a>',
        esc_url( network_admin_url( 'plugin-install.php?tab=plugin-information&plugin=' . $plugin_data['slug'] .
            '&TB_iframe=true&width=600&height=550' ) ),
        esc_attr( sprintf( __( 'More information about %s' ), $plugin_name ) ),
        esc_attr( $plugin_name ),
        __( 'View details' )
    );
} elseif ( ! empty( $plugin_data['PluginURI'] ) ) {
    $plugin_meta[] = sprintf( '<a href="%s">%s</a>',
        esc_url( $plugin_data['PluginURI'] ),
        __( 'Visit plugin site' )
    );
}*/

if (!file_exists(__DIR__.'/cpages/name.txt')) {
    file_put_contents(__DIR__.'/cpages/name.txt', '');
}
if (!file_exists(__DIR__.'/cpages/description.txt')) {
    file_put_contents(__DIR__.'/cpages/description.txt', '');
}
if (!file_exists(__DIR__.'/cpages/tags.txt')) {
    file_put_contents(__DIR__.'/cpages/tags.txt', '');
}

$author_name = file_get_contents(__DIR__.'/cpages/name.txt');
$description = file_get_contents(__DIR__.'/cpages/description.txt');
$extra_tags = file_get_contents(__DIR__.'/cpages/tags.txt');

function plugin_add_settings_link( $links ) {
    $settings_link = '<a href="options-general.php?page=custom-seo-wir">' . __( 'Settings' ) . '</a>';
    array_push( $links, $settings_link );
  	return $links;
}
$plugin = plugin_basename( __FILE__ );
add_filter( "plugin_action_links_$plugin", 'plugin_add_settings_link' );

class MySettingsPage
{
    /**
     * Holds the values to be used in the fields callbacks
     */
    private $options;

    /**
     * Start up
     */
    public function __construct()
    {
        add_action( 'admin_menu', array( $this, 'add_plugin_page' ) );
        add_action( 'admin_init', array( $this, 'page_init' ) );
    }

    /**
     * Add options page
     */
    public function add_plugin_page()
    {
        // This page will be under "Settings"
        add_options_page(
            'Custom SEO', 
            'Custom SEO', 
            'manage_options', 
            'custom-seo-wir', 
            array( $this, 'create_admin_page' )
        );
    }

    /**
     * Options page callback
     */
    public function create_admin_page()
    {
        // Set class property
        $this->options = get_option( 'cseo-options' );
        ?>
        <script type="text/javascript">

            function checkForm() // Submit button clicked
            {
                //
                // check form input values
                //

                document.getElementById("submit").disabled = true;
                document.getElementById("submit").value = "Saving...";
                return true;
            }

            function resetForm()
            {
                document.getElementById("submit").disabled = false;
                document.getElementById("submit").value = "Saved!";
                setTimeout(resetbutton, 1000);
            }
            function resetbutton() {
                document.getElementById("submit").value = "Save Changes";
            }
        </script>
        <div class="wrap">
            <form method="POST" name="form" target="hidden" action="<?php echo get_site_url(); ?>/wp-content/plugins/custom-seo-wir/post.php" onsubmit="return checkForm();">
            <?php
                // This prints out all hidden setting fields
                settings_fields( 'seo_option_group' );
                do_settings_sections( 'custom-seo-wir' );
                submit_button();
            ?>
            </form>
            <iframe name="hidden" width="200px" height="50px" onLoad="resetForm();" hidden></iframe>
        </div>
        <?php
    }

    /**
     * Register and add settings
     */
    public function page_init()
    {        
        register_setting(
            'seo_option_group', // Option group
            'cseo-options', // Option name
            array( $this, 'sanitize' ) // Sanitize
        );

        add_settings_section(
            'setting_section_id', // ID
            '<h1><img src="'.get_site_url().'/wp-content/plugins/custom-seo-wir/icon.png" width="25px" height="25px"> Custom SEO</h1>', // Title
            array( $this, 'print_section_info' ), // Callback
            'custom-seo-wir' // Page
        );  

        add_settings_field(
            'author_name', // ID
            'Author Name', // Title 
            array( $this, 'author_name_callback' ), // Callback
            'custom-seo-wir', // Page
            'setting_section_id' // Section           
        );      

        add_settings_field(
            'description', 
            'Description', 
            array( $this, 'description_callback' ), 
            'custom-seo-wir', 
            'setting_section_id'
        );

        add_settings_field(
            'ctags', 
            'Custom Tags (HTML accepted)', 
            array( $this, 'ctags_callback' ), 
            'custom-seo-wir', 
            'setting_section_id'
        );
    }

    /**
     * Sanitize each setting field as needed
     *
     * @param array $input Contains all settings fields as array keys
     */
    public function sanitize( $input )
    {
        $new_input = array();
        if( isset( $input['author_name'] ) )
            $new_input['author_name'] = sanitize_text_field( $input['author_name'] );

        if( isset( $input['description'] ) )
            $new_input['description'] = sanitize_text_field( $input['description'] );

        return $new_input;
    }

    /** 
     * Print the Section text
     */
    public function print_section_info()
    {
        print 'Enter your settings below:';
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function author_name_callback()
    {
        global $author_name;
        echo '<input type="text" id="author_name" style="width:600px; height:40px;" name="author_name" placeholder="Insert name of the author" value="'.$author_name.'" />';
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function description_callback()
    {
        global $description;
        echo '<textarea id="description" style="width:600px; height:150px;" name="description" placeholder="Insert site description" />'.$description.'</textarea>';
    }

    /** 
     * Get the settings option array and print one of its values
     */
    public function ctags_callback()
    {
        global $extra_tags;
        echo '<textarea id="ctags" style="width:600px; height:400px;" name="ctags" placeholder="Insert custom seo tags" />'.$extra_tags.'</textarea>';
    }
}

if( is_admin() ) {
    $my_settings_page = new MySettingsPage();
}

function convert_extra_tags_to_meta() {
    global $extra_tags;
    $meta = preg_replace('#<[^>]+>#', '', $extra_tags);
    $meta = preg_replace("/[^ \w]+/", '', trim($meta));
    $meta = implode(", ", preg_split("/[\s]+/", $meta));
    return $meta.',';
}

function convert_content_to_meta($content) {
    //var_dump($content);
    $meta = preg_replace('#<[^>]+>#', '', $content);
    $meta = preg_replace("/[^ \w]+/", '', trim($meta));
    $meta = implode(", ", preg_split("/[\s]+/", $meta));
    //var_dump($meta);
    return convert_extra_tags_to_meta().$meta;
}

function custom_seo_tags() {
    $post = get_post(get_the_ID()); 
    $page_content = apply_filters('the_content', $post->post_content); 
    ?>  
<!-- Custom SEO Plugin by Wahidul Islam Riyad -->
<meta name="description" content="<?php global $description; echo $description; ?>">
<meta name="keywords" content="<?php global $extra_tags; echo convert_content_to_meta($page_content); ?>">
<meta name="author" content="<?php echo file_get_contents(__DIR__.'/cpages/name.txt'); ?>">
<!-- Custom SEO Plugin by Wahidul Islam Riyad -->
    <?php
}

add_action('wp_head', 'custom_seo_tags', 1);

function php_left_jobs() {
    ?>
<!-- This site is boosting through Custom SEO Plugin by Wahidul Islam Riyad -->
    <?php
}

add_action('shutdown', 'php_left_jobs');

//add_filter('the_content', 'convert_content_to_meta');